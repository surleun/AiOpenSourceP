package com.example.project_01

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [fragment_createpost.newInstance] factory method to
 * create an instance of this fragment.
 */
class CreatePostFragment : Fragment(R.layout.fragment_create_post) {
    private var _binding: FragmentCreatePostBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentCreatePostBinding.bind(view)

        binding.tvTagSelect.setOnClickListener {
            val popup = PopupMenu(requireContext(), binding.tvTagSelect)
            popup.menu.add("게시물")
            popup.menu.add("핀")
            popup.setOnMenuItemClickListener { item ->
                binding.tvTagSelect.text = item.title
                true
            }
            popup.show()
        }

        // 나머지 버튼 리스너 (사진 첨부, 작성 완료) 구현
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment fragment_createpost.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            fragment_createpost().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}