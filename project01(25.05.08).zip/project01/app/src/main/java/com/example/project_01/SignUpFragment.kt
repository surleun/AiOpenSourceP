package com.example.project_01

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class SignUpFragment : Fragment(R.layout.fragment_sign_up) {
    private var _binding: FragmentSignupBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSignupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 프로필 사진 선택
        binding.ivProfilePhoto.setOnClickListener {
            // 사진 선택 인텐트 실행
            val intent = Intent(Intent.ACTION_PICK).apply {
                type = "image/*"
            }
            startActivityForResult(intent, REQUEST_CODE_CHOOSE_PHOTO)
        }

        // 인증번호 전송
        binding.btnSendVerification.setOnClickListener {
            val phone = binding.etSignUpPhone.text.toString()
            if (phone.isNotBlank()) {
                sendVerificationCode(phone)
            } else {
                Toast.makeText(requireContext(), "전화번호를 입력해주세요.", Toast.LENGTH_SHORT).show()
            }
        }

        // 인증번호 확인
        binding.btnVerifyCode.setOnClickListener {
            val code = binding.etVerificationCode.text.toString()
            verifyCode(code)
        }

        // 가입하기
        binding.btnSubmitSignUp.setOnClickListener {
            val id       = binding.etSignUpUserId.text.toString()
            val nickname = binding.etSignUpNickname.text.toString()
            val pw       = binding.etSignUpPassword.text.toString()
            val confirm  = binding.etSignUpConfirmPassword.text.toString()
            // TODO: 입력 검증 후 회원가입 로직 호출
        }
    }

    // 사진 선택 결과 처리
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CHOOSE_PHOTO && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            binding.ivProfilePhoto.setImageURI(uri)
            // TODO: 서버 업로드 또는 로컬 저장 처리
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun sendVerificationCode(phone: String) {
        // TODO: SMS API 호출
    }

    private fun verifyCode(code: String) {
        // TODO: 인증 서버 검증
    }

    companion object {
        private const val REQUEST_CODE_CHOOSE_PHOTO = 1001
    }
}
