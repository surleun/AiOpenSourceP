package com.example.project_01

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.project_01.ui.theme.Project_01Theme
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.project_01.api.MessageResponse
import com.example.project_01.api.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Project_01Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

class MainActivity : AppCompatActivity() {
    // TextView를 선언하여 화면에 데이터를 표시할 준비
    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 엣지 투 엣지 모드 활성화 (시스템 바를 제외한 화면을 모두 활용)
        enableEdgeToEdge()

        // 레이아웃을 설정 (activity_main.xml)
        setContentView(R.layout.activity_main)

        // XML 레이아웃에서 TextView를 찾아서 연결
        textView = findViewById(R.id.textView)

        // 시스템 바의 크기를 고려하여 뷰에 패딩을 적용
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // RetrofitClient의 API를 통해 서버 요청을 보내고 응답을 처리
        RetrofitClient.api.getHome().enqueue(object : Callback<MessageResponse> {
            // 서버 응답이 성공적일 경우 처리
            override fun onResponse(call: Call<MessageResponse>, response: Response<MessageResponse>) {
                if (response.isSuccessful) {
                    // 서버에서 받은 메시지를 TextView에 표시
                    textView.text = response.body()?.message ?: "응답 내용 없음"
                } else {
                    // 서버 응답이 오류일 경우 오류 코드와 함께 메시지 표시
                    textView.text = "서버 응답 오류: ${response.code()}"
                }
            }

            // 서버 요청이 실패할 경우 처리
            override fun onFailure(call: Call<MessageResponse>, t: Throwable) {
                // 네트워크 실패 메시지 표시
                textView.text = "네트워크 실패: ${t.message}"
            }
        })
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Project_01Theme {
        Greeting("Android")
    }
}