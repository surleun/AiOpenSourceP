package com.example.project_01

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.project_01.R
import com.example.project_01.databinding.FragmentHomeBinding

class HomeFragment : Fragment(R.layout.fragment_home) {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private fun updateSelection(selected: View) {
        listOf(binding.navMap, binding.navBoard, binding.navProfile).forEach {
            it.isSelected = (it == selected)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 인기 게시물 클릭
        binding.tvPopularPost1.setOnClickListener { navigateToPost("1") }
        binding.tvPopularPost2.setOnClickListener { navigateToPost("2") }
        binding.tvPopularPost3.setOnClickListener { navigateToPost("3") }

        // 인기 핀포인트 클릭
        binding.tvPopularPinpoint1.setOnClickListener { navigateToPinpoint("1") }
        binding.tvPopularPinpoint2.setOnClickListener { navigateToPinpoint("2") }
        binding.tvPopularPinpoint3.setOnClickListener { navigateToPinpoint("3") }

        // 하단 네비게이션
        binding.navMap.setOnClickListener {
            // 지도 화면으로 이동
            findNavController().navigate(R.id.action_home_to_map)
            updateSelection(binding.navMap)
        }
        binding.navBoard.setOnClickListener {
            // 게시판 화면으로 이동
            findNavController().navigate(R.id.action_home_to_board)
            updateSelection(binding.navBoard)
        }
        binding.navProfile.setOnClickListener {
            // 마이페이지 화면으로 이동
            findNavController().navigate(R.id.action_home_to_profile)
            updateSelection(binding.navProfile)
        }

        // 초기 선택 상태 (예: Home 탭)
        updateSelection(binding.navBoard) // Home화면이 게시판 역할이라면
    }

    private fun navigateToPost(postId: String) {
        val action = HomeFragmentDirections.actionHomeToPostDetail(postId)
        findNavController().navigate(action)
    }

    private fun navigateToPinpoint(pinpointId: String) {
        val action = HomeFragmentDirections.actionHomeToPinpointDetail(pinpointId)
        findNavController().navigate(action)
    }

    private fun updateSelection(selected: View) {
        listOf(binding.navMap, binding.navBoard, binding.navProfile).forEach {
            it.isSelected = (it == selected)
        }

    }

    private fun navigateToPost(postId: String) {
        // TODO: 상세 게시물 화면으로 이동, postId 전달
        val action = HomeFragmentDirections.actionHomeToPostDetail(postId)
        findNavController().navigate(action)
    }

    private fun navigateToPinpoint(pinId: String) {
        // TODO: 핀포인트 상세 화면으로 이동, pinId 전달
        val action = HomeFragmentDirections.actionHomeToPinpointDetail(pinId)
        findNavController().navigate(action)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}