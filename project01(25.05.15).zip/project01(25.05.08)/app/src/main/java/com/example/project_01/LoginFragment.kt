package com.example.project_01

+import androidx.navigation.fragment.findNavController
import android.os.Bundle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
+import android.view.LayoutInflater
+import android.view.View
+import android.view.ViewGroup
import com.example.project_01.ui.theme.Project_01Theme
+import com.example.project_01.databinding.FragmentLoginBinding

class LoginFragment : Fragment(R.layout.fragment_login) {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnLogin.setOnClickListener {
            val id = binding.etUserId.text.toString()
            val pw = binding.etPassword.text.toString()
            // TODO: 로그인 처리
        }
        binding.btnSignUp.setOnClickListener {
            -            // TODO: 회원가입 화면으로 이동
            +            // nav_graph.xml에 정의한 action 호출
            +            findNavController().navigate(R.id.action_loginFragment_to_signUpFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

@Composable
fun Greeting2(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview2() {
    Project_01Theme {
        Greeting2("Android")
    }
}